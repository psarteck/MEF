clear
clear
gcc *.c -Wall

