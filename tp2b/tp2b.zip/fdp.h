
float aij(float i, float j);


float A11(float *x);
float A00(float *x);
float A12(float *x);
float A22(float *x);
float BN(float *x);
float FOMEGA(float *x);
float FN(float *x);
float UD(float x[]);
